using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoEmprestimoLivros.Views.Home
{
    public class PoliticaPrivacidadeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
