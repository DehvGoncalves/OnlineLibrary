﻿namespace ProjetoEmprestimoLivros.Dto
{
    public class Livro
    {
    }
}
