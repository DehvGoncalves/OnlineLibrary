﻿using Microsoft.AspNetCore.Mvc;
using ProjetoEmprestimoLivros.Services.UsuariosService;

namespace ProjetoEmprestimoLivros.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IUsuariosInterface _usuariosInterface;
        public ClienteController(IUsuariosInterface usuariosInterface)
        {
            _usuariosInterface = usuariosInterface;
        }
        public async Task<IActionResult> Index(int? id)
        {
            var clientes = await _usuariosInterface.BuscarUsuarios(id);
            return View(clientes);
        }
    }
}
