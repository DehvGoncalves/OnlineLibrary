﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ProjetoEmprestimoLivros.Services.EmprestimoService;
using ProjetoEmprestimoLivros.Services.LivroService;
using ProjetoEmprestimoLivros.Services.SessaoService;
using ProjetoEmprestimoLivros.Services.UsuariosService;
using ProjetoEmprestimoLivros.Services.RelatorioService;
using System.Data;
using ProjetoEmprestimoLivros.Models;
using ProjetoEmprestimoLivros.Dto.Relatorio;
using ClosedXML.Excel;

namespace ProjetoEmprestimoLivros.Controllers
{
    public class RelatorioController : Controller
    {
        private readonly ISessaoInterface _sessao;
        private readonly ILivroInterface _livroInterface;
        private readonly IUsuariosInterface _usuariosInterface;
        private readonly IEmprestimoInterface _emprestimoInterface;
        private readonly IRelatorioInterface _relatorioInterface;
        private readonly IMapper _mapper;


        public RelatorioController(ISessaoInterface sessao,
            ILivroInterface livroInterface,
            IUsuariosInterface usuariosInterface,
            IEmprestimoInterface emprestimoInterface,
            IRelatorioInterface relatorioInterface,
            IMapper mapper)

        {
            _sessao = sessao;
            _livroInterface = livroInterface;
            _usuariosInterface = usuariosInterface;
            _emprestimoInterface = emprestimoInterface;
            _relatorioInterface = relatorioInterface;
            _mapper = mapper;
        }

        public IActionResult Index()
        {
            var sessaoUsuario = _sessao.BuscarSessao(); // Verifica se a sessão está ativa

            if (sessaoUsuario == null) //se o usuário não tiver logado
            {
                TempData["MensagemErro"] = "É necessário fazer login para extrair retórios"; // Mensagem de erro
                return RedirectToAction("Login", "Home");
            }
            if (sessaoUsuario.Perfil != Enum.PerfilEnum.Funcionario) // Se o usuário não for funcionário
            {
                TempData["MensagemErro"] = "Você não tem permissão para acessar essa página"; // Mensagem de erro
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        public async Task<ActionResult> Gerar(int id) // Vai receber o enum do relatório que queremos gerar
        {
            var tabela = new DataTable(); // Cria uma tabela

            switch (id)
            {
                case 1:
                    List<LivroModel> livros = await _livroInterface.BuscarLivros(); // Lista todos os livros
                    List<LivroRelatorioDto> dadosLivros = _mapper.Map<List<LivroRelatorioDto>>(livros); // Mapeia para o DTO
                    tabela = _relatorioInterface.ColetarDados(dadosLivros, id); // Coleta os dados e passa o id do relatório
                    break;
                case 2:
                    List<UsuarioModel> clientes = await _usuariosInterface.BuscarUsuarios(0); // Lista todos os usuários
                    List<UsuarioRelatorioDto> dadosClientes = new List<UsuarioRelatorioDto>(); // Cria uma lista vazia de DTO, vou usar para mapear um por um devido o join

                    foreach (var cliente in clientes)
                    {
                        dadosClientes.Add(
                        new UsuarioRelatorioDto
                        {
                            Id = cliente.Id,
                            NomeCompleto = cliente.NomeCompleto,
                            Email = cliente.Email,
                            Status = cliente.Status.ToString(),
                            Perfil = cliente.Perfil.ToString(),
                            Turno = cliente.Turno.ToString(),
                            Logradouro = cliente.Endereco.Logradouro,
                            Numero = cliente.Endereco.Numero,
                            CEP = cliente.Endereco.CEP,
                            Estado = cliente.Endereco.Estado,
                            Complemento = cliente.Endereco.Complemento,
                            DataCadastro = cliente.DataCadastro,
                            DataAlteracao = cliente.DataAlteracao
                        }
                        );
                    }
                    tabela = _relatorioInterface.ColetarDados(dadosClientes, id); // Coleta os dados e passa o id do relatório
                    break;

                case 3:
                    List<EmprestimoModel> emprestimos = await _emprestimoInterface.BuscarEmprestimos(); // Lista todos os empréstimos
                    List<EmprestimoRelatorioDto> dadosEmprestimos = _mapper.Map<List<EmprestimoRelatorioDto>>(emprestimos); // Mapeia para o DTO
                    tabela = _relatorioInterface.ColetarDados(dadosEmprestimos, id); // Coleta os dados e passa o id do relatório
                    break;
                case 4:
                    List<EmprestimoModel> emprestimosDevolvidos = await _emprestimoInterface.BuscarEmprestimosDevolvidos(); // Lista todos os empréstimos
                    List<EmprestimoRelatorioDto> dadosEmprestimosDevolvidos = _mapper.Map<List<EmprestimoRelatorioDto>>(emprestimosDevolvidos); //transforma os emprestimosModel em emprestimosRelatorioDto
                    tabela = _relatorioInterface.ColetarDados(dadosEmprestimosDevolvidos, id); // Coleta os dados e passa o id do relatório
                    break;
                case 5:
                    List<EmprestimoModel> emprestimosPendentes = await _emprestimoInterface.BuscarEmprestimosPendentes(); // Lista todos os empréstimos
                    List<EmprestimoRelatorioDto> dadosEmprestimosPendentes = _mapper.Map<List<EmprestimoRelatorioDto>>(emprestimosPendentes); //transforma os emprestimosModel em emprestimosRelatorioDto
                    tabela = _relatorioInterface.ColetarDados(dadosEmprestimosPendentes, id); // Coleta os dados e passa o id do relatório
                    break;
            }


            // Fazendo com que os dados sejam exportados
            using (XLWorkbook workbook = new XLWorkbook())
            {
                workbook.AddWorksheet(tabela, "Dados"); // Adiciona os dados que eu peguei do banco de dados no case acima e coloca na planilha
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    workbook.SaveAs(memoryStream);
                    return File(memoryStream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Dados.xlsx"); // Configuração para download em excel
                }
            }
        }
    }
}
