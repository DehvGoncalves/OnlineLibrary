﻿using Microsoft.AspNetCore.Mvc;

namespace ProjetoEmprestimoLivros.Controllers
{
    public class RelatorioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
