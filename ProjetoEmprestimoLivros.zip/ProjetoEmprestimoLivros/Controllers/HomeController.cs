﻿using Microsoft.AspNetCore.Mvc;
using ProjetoEmprestimoLivros.Dto.Home;
using ProjetoEmprestimoLivros.Services.HomeService;
using ProjetoEmprestimoLivros.Services.SessaoService;
using System.Diagnostics;

namespace ProjetoEmprestimoLivros.Controllers
{
    public class HomeController : Controller
    {
        private readonly ISessaoInterface _sessaoInterface;
        private readonly IHomeInterface _homeInterface;
        public HomeController(ISessaoInterface sessaoInterface, IHomeInterface homeInterface)
        {
            _sessaoInterface = sessaoInterface;
            _homeInterface = homeInterface;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var UsuarioSessao = _sessaoInterface.BuscarSessao();
            if (UsuarioSessao == null)
            {
                ViewBag.LayoutPagina = "_Layout";
            }
            else
            {
                ViewBag.LayoutPagina = "_LayoutLogado";
            }
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            if (_sessaoInterface.BuscarSessao() != null)
            {

                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginDto loginDto)
        {
            if (ModelState.IsValid)
            {
                var login = await _homeInterface.RealizarLogin(loginDto);

                if(login.Status == false) //relembrando que oque a gente ta recebendo aqui é o objeto RespostaModel
                {
                    TempData["MensagemErro"] = login.Mensagem;
                    return View(loginDto);
                }
                if(login.Dados.Status == false)
                {
                    TempData["MensagemErro"] = "Usuário Bloqueado";
                    return View("Login");
                }

                _sessaoInterface.CriarSessao(login.Dados);
                TempData["MensagemSucesso"] = login.Mensagem;

                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View(loginDto);
            }
        }
    }
}