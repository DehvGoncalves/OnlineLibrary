﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using ProjetoEmprestimoLivros.Models;

namespace ProjetoEmprestimoLivros.Services.EmprestimoService
{
    public interface IEmprestimoInterface
    {
        //Resposta Model é oque nos ajuda a mostrar mensagens específicas para o usuário
        Task<RespostaModel<EmprestimoModel>> Emprestar(int livroId); //Vai ser do tipo RespostaModel e esse resposta model vai ser do tipo EmprestimoModel que recebe um livroId
        Task<List<EmprestimoModel>> BuscarEmprestimosFiltro(UsuarioModel usuarioSessao, string pesquisar); //Vai retornar uma lista de emprestimos
        Task<List<EmprestimoModel>> BuscarEmprestimos (UsuarioModel usuarioSessao); //Vai retornar uma lista de emprestimos de um usuário específico
    }
}
