﻿namespace ProjetoEmprestimoLivros.Services.EmprestimoService
{
    internal class ctor
    {
    }
}