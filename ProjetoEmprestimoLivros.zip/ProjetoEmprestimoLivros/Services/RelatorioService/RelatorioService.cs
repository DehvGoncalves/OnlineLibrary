﻿using AutoMapper;
using Newtonsoft.Json;
using ProjetoEmprestimoLivros.Dto.Relatorio;
using ProjetoEmprestimoLivros.Enum;
using System.Data;

namespace ProjetoEmprestimoLivros.Services.RelatorioService
{
    public class RelatorioService : IRelatorioInterface
    {
        readonly IMapper _mapper;
        public RelatorioService(IMapper mapper)
        {
            _mapper = mapper;
        }

        public DataTable ColetarDados<T>(List<T> dados, int idRelatorio)
        {
            DataTable dataTable = new DataTable();

            //O TableName vai ser referente o id do relatório que recebemos
            dataTable.TableName = RelatorioEnum.GetName(typeof(RelatorioEnum), idRelatorio);
            //pegando o primeiro elemento da lista e pegando as propriedades dele, a propriedade é o nome da coluna dos Dtos cada propriedade é uma coluna
            var colunas = dados.First().GetType().GetProperties();

            foreach (var coluna in colunas)
            {
                //pra cada coluna que estamos passamos estamos adcioando o nome delas e o tipo
                dataTable.Columns.Add(coluna.Name, coluna.PropertyType); //Adiciona as colunas na tabela, temos que colocar o nome da coluna e o tipo dela
            }

            switch (idRelatorio)
            {
                case 1:
                    var dadosLivro = JsonConvert.SerializeObject(dados); //Estamos recebemos em Json e transformando em string
                    var dadosLivroModel = JsonConvert.DeserializeObject < List<LivroRelatorioDto>>(dadosLivro); //Estamos transformando a string em um objeto do tipo LivroRelatorioDto
                   if(dadosLivroModel != null)
                    {
                        return ExportarLivro(dataTable, dadosLivroModel);
                    }
                    break;
            }
            return new DataTable();
        }
        public DataTable ExportarLivro(DataTable data, List<LivroRelatorioDto> dados)
        {
            //pra cada registro que temos vamos adicionar uma linha na tabela do excel
            foreach (var dado in dados)
            {
                //a sequencia dos dados deve ser na msm ordem do nosso LivroRelatoDto
                data.Rows.Add(dado.Id, dado.Titulo, dado.Descricao, dado.ISBN, dado.Autor, dado.Genero, dado.AnoPublicacao, dado.QuantidadeEmEstoque);

            }//Depos de passar pelo foreach e criar cada uma das linhas vamos retornar a tabela
            return data;
        }
    }
}
