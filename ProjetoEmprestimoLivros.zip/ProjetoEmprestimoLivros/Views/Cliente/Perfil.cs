﻿namespace ProjetoEmprestimoLivros.Views.Cliente
{
    public class Perfil
    {
    }
}
