using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoEmprestimoLivros.Views.Home
{
    public class ApresentacaoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
