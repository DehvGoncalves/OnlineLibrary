using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoEmprestimoLivros.Views
{
    public class EmprestimoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
