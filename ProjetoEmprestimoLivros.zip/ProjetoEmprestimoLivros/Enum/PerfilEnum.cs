﻿namespace ProjetoEmprestimoLivros.Enum
{
    public enum PerfilEnum
    {
        Funcionario = 1,
        Cliente = 0
    }
}
