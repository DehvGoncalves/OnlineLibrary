﻿namespace ProjetoEmprestimoLivros.Enum
{
    public enum RelatorioEnum
    {
        Livros = 1,
        Clientes = 2,
        Emprestimos = 3,
        Emprestimos_Devolvidos = 4,
        Emprestimos_Pendentes = 5
    }
}
