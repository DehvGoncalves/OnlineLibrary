﻿namespace ProjetoEmprestimoLivros.Enum
{
    public enum TurnoEnum
    {
        Manha = 1,
        Tarde = 2,
        Noite = 3,
        Cliente = 0 //Se o usuário for um cliente, ele não tem turno então ele pode comprar quando quiser 
    }
}
